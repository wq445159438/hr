create type JOB_TRANSFEROBJECT as object (
  JT_ID               number(2),
  JT_USERID           number(5),
  JT_USERNAME         varchar2(50),
  JT_WORKID           number(5),
  JT_BEFORE_DEP       number(5),
  JT_BEFORE_POS       number(5),
  JT_AFTER_DEP        number(5),
  JT_AFTER_POS        number(5),
  JT_DATE             date,
  JT_REMARKS          varchar2(200)
)
/

