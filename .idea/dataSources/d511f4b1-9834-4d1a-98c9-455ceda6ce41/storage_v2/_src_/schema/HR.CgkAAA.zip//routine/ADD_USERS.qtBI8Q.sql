create procedure add_users(
  i_u_name in varchar2,
  i_workId in varchar2,
  i_sex in number,
  i_birthday in date,
  i_phone in varchar2,
  i_address in varchar2,
  i_dep_id in number,
  i_pos_id in number,
  i_s_ban in date,
  i_x_ban in date,
  i_u_remarks in varchar2,
  i_identityCard in varchar2,
  i_password in varchar2
)
  is
begin
  lock table users in share update mode;
  insert into USERS(u_id, u_name, workid, sex, birthday, phone, address, dep_id, pos_id, s_ban, x_ban, u_remarks,
  identitycard, password, U_STATE) values (USERS_ID.nextval,i_u_name,i_workId,i_sex,i_birthday,i_phone,i_address,i_dep_id,i_pos_id,
  i_s_ban,i_x_ban,i_u_remarks,i_identityCard,i_password,0);
end;
/

