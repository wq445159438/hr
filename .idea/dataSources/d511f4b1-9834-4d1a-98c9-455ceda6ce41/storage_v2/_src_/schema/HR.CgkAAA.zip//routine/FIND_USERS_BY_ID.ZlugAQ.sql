create procedure FIND_USERS_BY_ID(
  i_u_id in number,
  o_users out sys_refcursor
)
is
begin
  lock table users , DEPARTMENT , POSITION in share mode ;
  open o_users
  for
  select u.*,dep.DEP_NAME,pos.POS_NAME
  from USERS u
  left join department dep
  on dep.DEP_ID = u.DEP_ID
  left join POSITION pos
  on pos.POS_ID = u.POS_ID
  where u.u_id = i_u_id;
end;
/

