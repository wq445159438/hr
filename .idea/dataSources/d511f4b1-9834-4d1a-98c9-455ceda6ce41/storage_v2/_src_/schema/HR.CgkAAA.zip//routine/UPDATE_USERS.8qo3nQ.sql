create procedure UPDATE_USERS(
  i_sex in number,
  i_birthday in date,
  i_phone in varchar2,
  i_address in varchar2,
  i_dep_id in number,
  i_pos_id in number,
  i_identityCard in varchar2,
  i_u_id in number,
  i_password in varchar2,
  i_s_ban in date,
  i_x_ban in date
)
is
  temp number;
begin
  select u_id into temp from users where u_id = i_u_id for UPDATE ;
  update users set SEX=i_sex,BIRTHDAY=i_birthday,PHONE=i_phone,ADDRESS=i_address,DEP_ID=i_dep_id,
      POS_ID=i_pos_id,IDENTITYCARD=i_identityCard,PASSWORD=i_password,S_BAN=i_s_ban,X_BAN=i_x_ban
      where u_id = i_u_id;
end;
/

