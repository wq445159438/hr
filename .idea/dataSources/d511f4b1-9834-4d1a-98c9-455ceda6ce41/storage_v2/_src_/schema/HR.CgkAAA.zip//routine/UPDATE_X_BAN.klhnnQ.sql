create procedure UPDATE_X_BAN(
  i_att_userid in number,
  i_att_leave in number
)
is
  temp number;
  begin
    select att_id into temp from ATTENDANCE where ATT_USERID = 1 and (ATT_S_BAN >= to_date(sysdate)) and (ATT_S_BAN < to_date(sysdate+1)) for UPDATE ;
    update ATTENDANCE set ATT_X_BAN = sysdate, ATT_LEAVE = i_att_leave where ATT_USERID = 1 and (ATT_S_BAN >= to_date(sysdate)) and (ATT_S_BAN < to_date(sysdate+1));
end;
/

