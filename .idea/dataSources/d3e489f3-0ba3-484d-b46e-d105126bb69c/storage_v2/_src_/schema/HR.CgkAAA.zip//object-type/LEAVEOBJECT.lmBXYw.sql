create type LEAVEOBJECT as object (
  LEA_ID              number(5),
  LEA_USERID          number(5),
  LEA_USERNAME        varchar2(50),
  LEA_WORKID          number(5),
  LEA_DEP             number(5),
  LEA_POS             number(5),
  LEA_TYPE            number(1),
  LEA_DATE            date,
  LEA_DAYS            number(5),
  LEA_STATE           number(1),
  LEA_REMARKS         varchar2(200),
  FILING_DATE         date,
  LEA_REASON          varchar2(200)
)
/

