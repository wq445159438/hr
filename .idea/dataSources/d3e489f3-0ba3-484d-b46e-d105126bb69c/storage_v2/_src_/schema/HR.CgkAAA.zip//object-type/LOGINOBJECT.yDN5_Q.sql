create type LOGINOBJECT as object (
	WORKID              number(5),
	PASSWORD           varchar2(30)
)
/

