create type PAYROLLOBJECT as object(
  PAY_ID              number(5),
  PAY_USERID          number(5),
  PAY_USERNAME        varchar2(50),
  PAY_WORKID          number(5),
  PAY_GROSSPAY        number(20,2),
  PAY_BONUS           number(20,2),
  PAY_FINE            number(20,2),
  PAY_NETSALARY       number(20,2),
  PAY_DATE            date,
  PAY_REMARKS         varchar2(200)
)
/

