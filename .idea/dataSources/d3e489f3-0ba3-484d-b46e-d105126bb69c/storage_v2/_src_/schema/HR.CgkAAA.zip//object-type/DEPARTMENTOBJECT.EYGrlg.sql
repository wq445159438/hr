create type DEPARTMENTOBJECT as object (
  DEP_ID             number(5),
  DEP_NAME           varchar2(50),
  DEP_REMARKS        varchar2(200)
)
/

