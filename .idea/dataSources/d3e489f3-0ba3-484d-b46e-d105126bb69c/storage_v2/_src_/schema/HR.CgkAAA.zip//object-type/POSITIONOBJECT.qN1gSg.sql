create type POSITIONOBJECT as object (
  POS_ID              number(5),
  POS_NAME            varchar2(50),
  POS_REMARKS         varchar2(200)
)
/

