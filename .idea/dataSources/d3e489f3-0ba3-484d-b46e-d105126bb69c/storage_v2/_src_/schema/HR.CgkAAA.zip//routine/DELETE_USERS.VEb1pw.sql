create procedure delete_users (
  i_u_id in number
)
is
begin
  delete from users where U_ID = i_u_id;
end;
/

