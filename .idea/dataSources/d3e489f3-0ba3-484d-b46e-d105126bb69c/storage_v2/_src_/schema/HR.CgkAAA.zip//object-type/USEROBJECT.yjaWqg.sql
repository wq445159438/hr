create type userObject as object (
  U_ID                number(5),
  U_NAME              varchar2(50),
  WORKID              number(5),
  SEX                 number(1),
  BIRTHDAY            date,
  PHONE               varchar2(11),
  ADDRESS             varchar2(100),
  DEP_ID              number(2),
  POS_ID              number(2),
  S_BAN               date,
  X_BAN               date,
  U_REMARKS           varchar2(200),
  IDENTITYCARD        varchar2(18),
  PASSWORDS           varchar2(30),
  U_STATE             number(1)
)
/

