create type attendanceObject as object (
  ATT_ID              number(5),
  ATT_USERID          number(5),
  ATT_USERNAME        varchar2(50),
  ATT_WORKID          number(5),
  ATT_S_BAN           date,
  ATT_X_BAN           date,
  ATT_LATE            number(1),
  ATT_LEAVE           number(1),
  ATT_REMARKS         varchar2(200)
)
/

